import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import com.adobe.cq.sightly.WCMUse;

import javax.script.Bindings;
import java.util.*;

public class Child extends WCMUse{


    List list=null;

    @Override
    public void activate() throws Exception{
        System.out.println("in init");
        int s=Integer.parseInt(getProperties().get("number","1"));
       // Resource resource=getResource();
        Iterator iterator=getCurrentPage().listChildren();
        list=new ArrayList<>();

        while(iterator.hasNext()&& s!=0){
             list.add(iterator.next());
             s--;
        }


      }


    public List<Resource> getList(){

        return list;
    }

}


