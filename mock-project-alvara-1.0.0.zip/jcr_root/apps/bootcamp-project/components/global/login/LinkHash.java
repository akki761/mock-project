
import com.google.gson.*;
import org.apache.sling.api.resource.Resource;

import org.apache.sling.scripting.sightly.pojo.Use;
import java.util.*;

import javax.jcr.*;
import javax.script.Bindings;
import java.util.HashMap;
import java.util.Map;

public class LinkHash implements Use {
   HashMap<String, String> map;


   @Override
   public void init(Bindings bindings) {
        map = new HashMap<>();
       Resource resource = (Resource) bindings.get("resource");

       Value[] values = new Value[]{};
       PropertyIterator propItr = null;
       try {
           propItr = resource.adaptTo(Node.class).getProperties("links");
       } catch (RepositoryException e) {
           e.printStackTrace();
       }
       if (propItr.hasNext()) {
           Property prop = propItr.nextProperty();
           try {
               if (prop.isMultiple()) {
                   values = prop.getValues();
               } else {
                   values = (new Value[]{prop.getValue()});
               }
           } catch (RepositoryException e) {
               e.printStackTrace();
           }
       }

       for (Value value : values) {
           JsonParser parser = new JsonParser();JsonObject o=null;
           try {
               o = parser.parse(value.getString()).getAsJsonObject();
           } catch (RepositoryException e) {
               e.printStackTrace();
           }

           String a=o.get("linktext").toString();

           a=a.replaceAll("^\"|\"$", "");

           String b=o.get("link").toString().replaceAll("^\"|\"$", "");
           System.out.println(b);

           map.put(b,a);
       }

   }


   public Map<String, String> getMap() {
       return map;
   }


}
